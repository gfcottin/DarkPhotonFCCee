# This file was automatically created by FeynRules 2.3.49
# Mathematica version: 13.2.1 for Mac OS X ARM (64-bit) (January 27, 2023)
# Date: Tue 16 Jun 2026 15:48:20


from object_library import all_orders, CouplingOrder


QCD = CouplingOrder(name = 'QCD',
                    expansion_order = 99,
                    hierarchy = 1)

QED = CouplingOrder(name = 'QED',
                    expansion_order = 99,
                    hierarchy = 2)

